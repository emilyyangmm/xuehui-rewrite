import { NextRequest, NextResponse } from "next/server";

const GEMINI_API_KEY = process.env.GEMINI_API_KEY || "";
const GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent";

async function callGemini(prompt: string): Promise<string> {
  if (!GEMINI_API_KEY) throw new Error("请配置 GEMINI_API_KEY");
  const res = await fetch(`${GEMINI_URL}?key=${GEMINI_API_KEY}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }),
  });
  if (!res.ok) throw new Error(`Gemini 调用失败: ${res.status}`);
  const data = await res.json();
  if (data.error) throw new Error(data.error.message);
  return data.candidates?.[0]?.content?.parts?.[0]?.text || "";
}

// 清除舞台提示词：括号内的导演提示、语气说明等
function removeStageDirections(text: string): string {
  return text
    .replace(/[（(][^）)]{1,30}[）)]/g, "") // 删除括号内短提示
    .replace(/【[^】]{1,20}】/g, "")         // 删除【】内提示
    .replace(/\[.*?\]/g, "")                 // 删除[]内提示
    .replace(/^(开场|转折|结尾|高潮|铺垫)[：:]\s*/gm, "") // 删除段落标题
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

export async function POST(req: NextRequest) {
  try {
    const { text, industry, scriptType, selectedElements, selectedHooks } = await req.json();
    if (!text?.trim()) return NextResponse.json({ success: false, error: "请输入文案" }, { status: 400 });

    const scriptTypeDesc: Record<string, string> = {
      teach: "教知识（痛点开场→干货方法→效果展示）",
      show: "晒过程（真实场景→操作过程→最终结果）",
      opinion: "聊观点（社会现象→鲜明观点→情感共鸣）",
      story: "讲故事（戏剧冲突→意外转折→圆满结局）",
    };

    const elementsDesc = selectedElements?.length
      ? selectedElements.map((e: any) => `【${e.title}】`).join("、")
      : "自由组合";

    const hooksDesc = selectedHooks?.length ? `重点融入词根：${selectedHooks.join("、")}` : "";

    const prompt = `你是一位抖音爆款内容创作专家，精通薛辉短视频方法论。请对以下文案进行深度改写。

## 薛辉方法论核心（必须严格遵守）

### 三大心法
1. **粉丝经济本质**：目标是建立"喜欢和信任"，不是直接卖货
2. **情绪波点是灵魂**：必须有1-2个情绪锚点，通过"具体事件"来承载情绪，而非空喊
3. **事件大于情绪**：用真实的事件和场景传递感情，比直接表达情绪有力10倍

### 爆款选题公式
60%泛流量（叠加词根）+ 20%人设故事 + 20%转化内容

### 口播脚本黄金结构
- **开场3秒钩子**：用悬念/反常识/痛点问句直接抓注意力，不能用"大家好我是XXX"
- **中间干货**：快节奏，每句话都有信息量，不废话
- **结尾行动号召**：具体的互动引导（"评论区告诉我"、"点赞收藏防止迷路"）

### 语言要求
- 纯口语化，像真人说话，不能有书面语
- 短句为主，每句不超过15字
- 有节奏感，可以加语气词（啊、嘛、哎、对吧）
- **绝对禁止**：括号内的舞台提示、场景描述、语气说明（如"（开场）"、"（带点委屈）"、"（激动地）"）
- **绝对禁止**：段落标题（如"开场："、"转折："）
- 只输出纯台词，就像真人直接说出来的话

## 改写参数
- 行业：${industry}
- 脚本结构：${scriptTypeDesc[scriptType] || "教知识"}
- 使用爆款元素：${elementsDesc}
${hooksDesc ? `- ${hooksDesc}` : ""}

## 原始文案
${text}

## 输出格式（严格JSON，不要有任何多余内容）
{
  "topics": [
    "标题1（融入爆款词根，有强烈好奇心驱动）",
    "标题2",
    "标题3",
    "标题4",
    "标题5",
    "标题6",
    "标题7",
    "标题8"
  ],
  "script": "纯口播台词，无任何括号提示，无段落标题，直接可以念出来，200-350字"
}`;

    const raw = await callGemini(prompt);

    let result: { topics: string[]; script: string };
    try {
      const cleaned = raw.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
      result = JSON.parse(cleaned);
    } catch {
      result = { topics: [], script: raw };
    }

    // 清除舞台提示词
    result.script = removeStageDirections(result.script);
    result.topics = result.topics.map(t => t.replace(/^["「『]|["」』]$/g, "").trim());

    return NextResponse.json({ success: true, result });
  } catch (e: any) {
    return NextResponse.json({ success: false, error: e.message }, { status: 500 });
  }
}
